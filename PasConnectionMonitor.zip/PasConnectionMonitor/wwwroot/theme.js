// Apply theme to body element
window.applyTheme = function(themeClass) {
    // Remove existing theme classes
    document.body.classList.remove('theme-light', 'theme-dark');

    // Add the new theme class
    document.body.classList.add(themeClass);
};
