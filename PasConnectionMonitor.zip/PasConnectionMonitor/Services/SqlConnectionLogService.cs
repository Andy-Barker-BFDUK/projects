using Microsoft.Data.SqlClient;

namespace PasConnectionMonitor.Services;

public sealed class SqlConnectionLogService
{
    private readonly IConfiguration _configuration;

    // store configuration access so the service can read the sql connection string.
    public SqlConnectionLogService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    // get connection log rows from the view starting at the selected time window.
    public async Task<IReadOnlyList<ConnectionLogRow>> GetRowsSinceAsync(DateTime since, int maxRows, CancellationToken cancellationToken)
    {
        var connectionString = _configuration.GetConnectionString("PasMonitor");
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException("Connection string 'PasMonitor' is not configured.");
        }

        const string sql = """
            select top (@Top)
                Captured_Time,
                [PRD-SMPAS01],
                [PRD-SMPAS02],
                [PRD-SMPAS03],
                [PRD-SMPAS04],
                [PRD-SMPAS05],
                Granular_Data
            from dbo.vw_Pas_Connection_Logs
            where Captured_Time >= @Since
            order by Captured_Time desc;
            """;

        var rows = new List<ConnectionLogRow>();

        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@Top", maxRows);
        command.Parameters.AddWithValue("@Since", since);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            if (reader.IsDBNull(0))
            {
                continue;
            }

            rows.Add(new ConnectionLogRow(
                CapturedTime: reader.GetDateTime(0),
                PrdSmpas01: reader.IsDBNull(1) ? 0 : Convert.ToInt32(reader.GetValue(1)),
                PrdSmpas02: reader.IsDBNull(2) ? 0 : Convert.ToInt32(reader.GetValue(2)),
                PrdSmpas03: reader.IsDBNull(3) ? 0 : Convert.ToInt32(reader.GetValue(3)),
                PrdSmpas04: reader.IsDBNull(4) ? 0 : Convert.ToInt32(reader.GetValue(4)),
                PrdSmpas05: reader.IsDBNull(5) ? 0 : Convert.ToInt32(reader.GetValue(5)),
                GranularData: !reader.IsDBNull(6) && Convert.ToBoolean(reader.GetValue(6))));
        }

        rows.Reverse();
        return rows;
    }
}

// connection log data model pulled from the db view.
public sealed record ConnectionLogRow(
    DateTime CapturedTime,
    int PrdSmpas01,
    int PrdSmpas02,
    int PrdSmpas03,
    int PrdSmpas04,
    int PrdSmpas05,
    bool GranularData);
